package aula7;

import java.util.Scanner;

public class ex4 {

	public static void main(String[] args) {
		
		Scanner in = new Scanner(System.in);
		
		int valor1, valor2, valor3;
		
		System.out.println("Digite o valor 1");
		valor1 = in.nextInt();
		
		System.out.println("Digite o valor 2");
		valor2 = in.nextInt();
		
		System.out.println("Digite o valor 3");
		valor3 = in.nextInt();
		
		if (valor1 != valor2 || valor2 != valor3 || valor1 != valor3) {
		
			if (valor1 < valor2 && valor1 < valor3) {	
				System.out.println("O menor valor = " + valor1);
			}
			else if (valor2 <valor3) {
				System.out.println("O menor valor = " + valor2);
			}
			else {
				System.out.println("O menor valor = " + valor3);	
			}	
			
			
		}
		
		else {
			
			System.out.println("Os valores sao iguais");
		}
			
		
		
	}

}
