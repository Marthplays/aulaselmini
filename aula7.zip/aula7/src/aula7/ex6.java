package aula7;

import java.util.Scanner;

public class ex6 {

	public static void main(String[] args) {
		
		Scanner in = new Scanner(System.in);
		String cargo;
		int tempodeserviço;
		double salarioAtual, salarioNovo;
		
		System.out.println("Digite o seu cargo");
		cargo = in.next();
		
		System.out.println("Digite seu tempo de serviço em anos");
		tempodeserviço = in.nextInt();
		
		System.out.println("Digite seu salário atual");
		salarioAtual = in.nextDouble();
		
		if (cargo.equalsIgnoreCase("gerente") || cargo.equalsIgnoreCase("engenheiro") || cargo.equalsIgnoreCase("tecnico"))
			
		if (cargo.equalsIgnoreCase("gerente")) {
			if (tempodeserviço >= 5) {
				salarioNovo = salarioAtual * 1.10;
			}
			else if (tempodeserviço >=3) {
				salarioNovo = salarioAtual * 1.09;
			}
			else {
				salarioNovo = salarioAtual * 1.08;
			}
		}
			
		if (cargo.equalsIgnoreCase("engenheiro")) {
			if (tempodeserviço >= 5) {
				salarioNovo = salarioAtual * 1.11;
			}
			else if (tempodeserviço >=3) {
				salarioNovo = salarioAtual * 1.10;
			}
			else {
				salarioNovo = salarioAtual * 1.09;
			}
		}
		
		if (cargo.equalsIgnoreCase("gerente")) {
			if (tempodeserviço >= 5) {
				salarioNovo = salarioAtual * 1.12;
			}
			else if (tempodeserviço >=3) {
				salarioNovo = salarioAtual * 1.11;
			}
			else {
				salarioNovo = salarioAtual * 1.10;
			}
		}
		
		else {
			salarioNovo = salarioAtual * 1.05;
		}
		
		System.out.println("Seu salario novo será R$" + salarioNovo + "reais");
		System.out.println("Sua diferença salarial é R$" + (salarioNovo - salarioAtual));
		
		in.close();
		
	}

}
