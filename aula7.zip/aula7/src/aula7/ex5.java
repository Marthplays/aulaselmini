package aula7;

import java.util.Scanner;

public class ex5 {
	
	public static void main(String[] args) {

	Scanner in = new Scanner(System.in);
	
	int valor1, valor2, valor3, temp;
	
	System.out.println("Digite o valor 1");
	valor1 = in.nextInt();
	
	System.out.println("Digite o valor 2");
	valor2 = in.nextInt();
	
	System.out.println("Digite o valor 3");
	valor3 = in.nextInt();
	
	if (valor1 > valor2) {
		
		temp = valor1;
		valor1 = valor2;
		valor2 = temp;
		
	}
	
	if (valor1 > valor2) {
		
		temp = valor1;
		valor1 = valor3;
		valor3 = temp;
	}
	
	if (valor2 > valor3) {
		
		temp = valor2;
		valor2 = valor3;
		valor3 = temp;
		
	}
	
	System.out.println(valor1 + " " + valor2 + " " + valor3);
	
	}
}
