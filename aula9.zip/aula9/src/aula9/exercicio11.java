package aula9;

import java.util.Scanner;

public class exercicio11 {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		long numero, diferenca = 0, divisor;
		
		System.out.println("Digite um número: ");
		numero = in.nextInt();
		
		if (numero < 0) {
			System.out.println("Digite um número inteiro e positivo!");
		} else {
		for(divisor = 2; divisor <= numero; divisor++) {
			if (numero % divisor == 0) {
				diferenca++;
				break;
			}
		}
		
		System.out.println(diferenca == 0 && numero != 1 ? "É primo" : "Não é primo");
		
		in.close();
		}
	}
}	

