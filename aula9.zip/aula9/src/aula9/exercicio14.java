package aula9;

import java.util.Scanner;

public class exercicio14 {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		int n;
		double y = 0;
		int sinal = 1;

		System.out.println("Digite um número inteiro e positivo");
		n = in.nextInt();

		for (int i = 1; i <= n; i++) {
			y = y + (double) 1 / i * sinal;
			sinal = sinal * -1;
		}
		System.out.println("y = " + y);

	}

}
