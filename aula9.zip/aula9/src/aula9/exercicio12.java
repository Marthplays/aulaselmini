package aula9;

import java.util.Scanner;

public class exercicio12 {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		double valor, valorTotal;
		String resposta = "sim";
		
		System.out.println("Digite o valor das compras");
		valor = in.nextDouble();
		
		System.out.println("Para forma de pagamento à vista digite sim, em duas vezes digite não");
		resposta = in.next();
		
		if (resposta.equals("sim")) {
			valorTotal = valor * 0.90;
			System.out.println("O valor das suas compras com desconto será " + valorTotal);
		} else {
			valorTotal = valor * 1.155;
			System.out.println("O valor das suas compras com acréscimo em duas vezes de " + valorTotal);
		}
		
		in.close();
	}

}
